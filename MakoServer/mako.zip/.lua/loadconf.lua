local conf={}
if _G.mako.cfgfname then
   local fp=io.open(_G.mako.cfgfname)
   if fp then
      local f,e=load(fp:read"*a","","bt",conf)
      fp:close()
      if f then
         pcall(f)
      end
   end
end
return conf
