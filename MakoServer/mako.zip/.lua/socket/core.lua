--[[

$Id: core.lua 2282 2011-01-15 03:35:20Z wini $ 

socket.core.lua: Included by socket.lua
Provides a compatibility layer between ba.socket and Lua sockets.
See lsocket.c for more info.
Copyright (C) Real-Time Logic 2010

--]]

local b = _G
local s = ba.socket
assert(s, "BA socket lib (lsocket.c) not included in build")
assert(sockcompat, "BA socket lib compat mode in lsocket.c removed")
b.socket=sockcompat
local socket=b.socket


function socket.gettime()
   return b.os.time()
end

function socket.sleep(secs)
   ba.sleep(secs*1000)
end

local sharkssl
function socket.secure(shark)
   sharkssl=shark
end

local tinsert=table.insert
local tremove=table.remove
local tconcat=table.concat
local sgmatch=string.gmatch
local sfind=string.find
local fmt=string.format

local _ENV={}

local tcpM = { __index = {} }
local function initSock(self)
   if self.s then self.s:close() end
   self.s=nil
   self.received=0
   self.sent=0
   self.age=b.os.time()
end

function tcpM.__index:bind(address, port)
   self.op = { intf=address, port=port, shark=sharkssl }
   return true
end
function tcpM.__index:close()
   return self.s and self.s:close() or false
end

function tcpM.__index:connect(address, port)
   local e
   initSock(self)
   self.s,e=s.connect(address, port, self.op and self.op or {shark=sharkssl})
   if self.s then return true end
   return nil,e
end

function tcpM.__index:certificate()
   return self.s:certificate()
end

function tcpM.__index:getsockname()
   return self.s:getsockname()
end

function tcpM.__index:upgrade(shark)
   return self.s:upgrade(shark)
end

function tcpM.__index:getpeername()
   return self.s:getpeername()
end

function tcpM.__index:getstats()
   return self.received,self.sent,self.age
end

function tcpM.__index:setstats(received, sent, age)
   self.received,self.sent,self.age=received,sent,age
   return 1
end

function tcpM.__index:listen(backlog)
   local e
   initSock(self)
   self.s,e=ba.socket.bind(self.op.port, self.op)
   if self.s then return true end
   return nil,e
end

function tcpM.__index:settimeout(value, mode)
   self.timeoutSecs=value
end

local function getBuf(self)
   if self.tbuf then
      t=self.tbuf
      self.tbuf=nil
      if self.nextbuf then
         tinsert(t, self.nextbuf)
         self.nextbuf=0
      end
      return t
   end
   return nil
end

function tcpM.__index:receive(pattern, prefix)
   local s=self.s
   local d,e,t
   local tmo = self.timeoutSecs and self.timeoutSecs*1000 or nil
   pattern = pattern and pattern or "*l"
   if pattern == "*a" then
      t=getBuf(self)
      if not t then t = {} end
      if prefix then tinsert(t,prefix,1) end
      while true do
         d,e = s:read(tmo)
         if not d then break end
         tinsert(t,d)
      end
      t=tconcat(t)
      if #t > 0 then return t end
      return nil, e
   end
   if pattern == "*l" then
      if self.tbuf then
         self.tix=self.tix+1
         if self.tix >= #self.tbuf then
            self.tbuf=nil
         else
            d=self.tbuf[self.tix]
            return prefix and prefix..d or d
         end
      end
      d,e=s:read(tmo)
      if not d then return nil,e end
      if not sfind(d,"\n",1,true) then return d end
      d=fmt("%s%s\n",self.nextbuf and self.nextbuf or "",d)
      self.nextbuf=nil
      local t={}
      for l in sgmatch(d, "([^\r\n]*)\r?\n") do tinsert(t, l) end
      if #t[#t]~=0 then
         self.nextbuf=#t[#t]
         tremove(t)
      end
      self.tix=1
      self.tbuf=t
      return t[1]
   end
   t=getBuf(self)
   if t then
      if prefix then tinsert(t,prefix,1) end
      return tconcat(t)
   end
   d,e=s:read(tmo, pattern) -- pattern should be len
   if d and prefix then
      return prefix..d
   end
   return d,e
end

function tcpM.__index:send(...)
   return self.s:write(...)
end

function tcpM.__index:setoption(...)
   return self.s:setoption(...)
end

function tcpM.__index:shutdown()
   return self.s:close() -- No shutdown thus use close
end

function tcp()
   return b.setmetatable({},tcpM)
end

BLOCKSIZE=512
socket.tcp=tcp

return _ENV
